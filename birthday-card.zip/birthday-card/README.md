# 给小波的生日贺卡

这个文件夹里是一份可以在微信里打开的静态网页贺卡。

## 预览

在电脑上直接打开 `index.html` 就可以预览。

## 发到微信

微信里最稳定的方式是把整个 `birthday-card` 文件夹上传到一个静态网页托管服务，然后把生成的网页链接发给对方。上传时请保持这些文件在同一个文件夹里：

- `index.html`
- `styles.css`
- `script.js`
- `assets/cover.png`

如果你已经有服务器、GitHub Pages、Netlify、Vercel 或类似工具，把这个文件夹作为网页根目录上传即可。
