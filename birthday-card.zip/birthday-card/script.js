const card = document.querySelector("#card");
const openButton = document.querySelector("#openLetter");
const backButton = document.querySelector("#backToCover");
const shareButton = document.querySelector("#shareCard");
const progress = document.querySelector(".progress");
const toast = document.querySelector("#toast");

let toastTimer;

function showToast(message) {
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add("is-visible");
  toastTimer = window.setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 2200);
}

function openLetter() {
  card.classList.add("is-open");
  window.setTimeout(() => {
    document.querySelector("#letter").scrollIntoView({ behavior: "smooth", block: "start" });
  }, 120);
}

function closeLetter() {
  window.scrollTo({ top: 0, behavior: "smooth" });
  window.setTimeout(() => {
    card.classList.remove("is-open");
  }, 180);
}

function updateProgress() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  const percent = scrollable <= 0 ? 0 : Math.min(100, Math.max(0, (window.scrollY / scrollable) * 100));
  progress.style.setProperty("--progress", `${percent}%`);
}

async function shareCard() {
  const shareData = {
    title: "生日快乐，小波",
    text: "给小波的一封生日信",
    url: window.location.href
  };

  if (navigator.share) {
    try {
      await navigator.share(shareData);
      return;
    } catch (error) {
      if (error.name === "AbortError") return;
    }
  }

  try {
    await navigator.clipboard.writeText(window.location.href);
    showToast("链接已复制，可以粘贴发送给他");
  } catch {
    showToast("可以用微信右上角分享给他");
  }
}

openButton.addEventListener("click", openLetter);
backButton.addEventListener("click", closeLetter);
shareButton.addEventListener("click", shareCard);
window.addEventListener("scroll", updateProgress, { passive: true });
window.addEventListener("resize", updateProgress);
updateProgress();
